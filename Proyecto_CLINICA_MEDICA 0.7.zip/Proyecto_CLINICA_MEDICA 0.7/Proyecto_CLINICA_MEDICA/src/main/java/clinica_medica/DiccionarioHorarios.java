
package clinica_medica;

import static clinica_medica.Proyecto_CLINICA_MEDICA.grabarDiccionarioHorarios;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.io.Serializable;

public class DiccionarioHorarios implements Serializable {
    private Map<String, Map<Integer, LocalTime>> dias;

    public DiccionarioHorarios(){
        dias = new HashMap<>();
        String[] diasSemana  = {"Domingo","Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado"};
        for (String dia : diasSemana){
            Map<Integer, LocalTime> horasMedicos = new HashMap<>();
            dias.put(dia, horasMedicos);
        }
    }
    
    public Map<Integer, LocalTime> acceso(String dia){
        return dias.get(dia);
    }
    
    public void agregarAlDicionarioInterno(Lista_Medicos medicos){
        DiccionarioHorarios dict = new DiccionarioHorarios();
        for (int i = 0; i < medicos.largo(); i++){
            Medico medico = medicos.acceso(i);
            int identificacion = medico.getIdentificacion();
            String LI = medico.getLM();
            String LF = medico.getLF();
            String KI = medico.getKM();
            String KF = medico.getKF();
            String MI = medico.getMM();
            String MF = medico.getMF();
            String JI = medico.getJM();
            String JF = medico.getJF();
            String VI = medico.getVM();
            String VF = medico.getVF();
            String SI = medico.getSM();
            String SF = medico.getSF();
            String DI = medico.getDM();
            String DF = medico.getDF();
            
            
            int cont = 0;
            String[] horas = {LI,LF,KI,KF,MI,MF,JI,JF,VI,VF,SI,SF,DI,DF};
            LocalTime h = null;
            for (String hora : horas){
                if (hora != "N"){
                    DateTimeFormatter formato = DateTimeFormatter.ofPattern("H:mm");
                    try{
                        h = LocalTime.parse(hora, formato);
                    }catch(Exception e) {
                        e.printStackTrace();
                    }
                    String dia;
                    switch(cont){
                        case 0,1 ->dia = "Lunes";
                        case 2,3 ->dia = "Martes";
                        case 4,5 ->dia = "Miercoles";
                        case 6,7 ->dia = "Jueves";
                        case 8,9 ->dia = "Viernes";
                        case 10,11 ->dia = "Sabado";
                        case 12,13 ->dia = "Domingo";
                        default -> dia = "";
                        
                    }
                    if (!dia.isEmpty()){
                        Map<Integer, LocalTime> horasMedicos = dict.acceso(dia);
                        if (horasMedicos != null){
                            horasMedicos.put(identificacion, h);
                    }
                    
                }
                cont++;
            }
            grabarDiccionarioHorarios(dict);
        }
        
    }
    
    }
}
