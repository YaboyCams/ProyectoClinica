/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clinica_medica;

import java.io.Serializable;

/**
 *
 * @author callo
 */
public class HorariosTrabajo implements Serializable{
    
    private String LM;
    private String LF;
    private String KM;
    private String KF;
    private String MM;
    private String MF;
    private String JM;
    private String JF;
    private String VM;
    private String VF;
    private String SM;
    private String SF;
    private String DM;
    private String DF;
    
    public HorariosTrabajo(){}
    public HorariosTrabajo(String pLM, String pLF, String pKM, String pKF, String pMM, String pMF, String pJM, String pJF, String pVM, String pVF, String pSM, String pSF, String pDM, String pDF){
        setLM(pLM);
        setLF(pLF);
        setKM(pKM);
        setKF(pKF);
        setMM(pMM);
        setMF(pMF);
        setJM(pJM);
        setJF(pJF);
        setVM(pVM);
        setVF(pVF);
        setSM(pSM);
        setSF(pSF);
        setDM(pDM);
        setDF(pDF);
    }
    public String getLM() {
        return LM;
    }

    public void setLM(String pLM) {
        LM = pLM;
    }

    public String getLF() {
        return LF;
    }

    public void setLF(String pLF) {
        LF = pLF;
    }

    public String getKM() {
        return KM;
    }

    public void setKM(String pKM) {
        KM = pKM;
    }

    public String getKF() {
        return KF;
    }

    public void setKF(String pKF) {
        KF = pKF;
    }

    public String getMM() {
        return MM;
    }

    public void setMM(String pMM) {
        MM = pMM;
    }

    public String getMF() {
        return MF;
    }

    public void setMF(String pMF) {
        MF = pMF;
    }

    public String getJM() {
        return JM;
    }

    public void setJM(String pJM) {
        JM = pJM;
    }

    public String getJF() {
        return JF;
    }

    public void setJF(String pJF) {
        JF = pJF;
    }

    public String getVM() {
        return VM;
    }

    public void setVM(String pVM) {
       VM = pVM;
    }

    public String getVF() {
        return VF;
    }

    public void setVF(String pVF) {
        VF = pVF;
    }

    public String getSM() {
        return SM;
    }

    public void setSM(String pSM) {
        SM = pSM;
    }

    public String getSF() {
        return SF;
    }

    public void setSF(String pSF) {
        SF = pSF;
    }

    public String getDM() {
        return DM;
    }

    public void setDM(String pDM) {
        DM = pDM;
    }

    public String getDF() {
        return DF;
    }

    public void setDF(String pDF) {
        DF = pDF;
    }
    public String toString() {
        return "LM: " + getLM() + "\n" +
           "LF: " + getLF() + "\n" +
           "KM: " + getKM() + "\n" +
           "KF: " + getKF() + "\n" +
           "MM: " + getMM() + "\n" +
           "MF: " + getMF() + "\n" +
           "JM: " + getJM() + "\n" +
           "JF: " + getJF() + "\n" +
           "VM: " + getVM() + "\n" +
           "VF: " + getVF() + "\n" +
           "SM: " + getSM() + "\n" +
           "SF: " + getSF() + "\n" +
           "DM: " + getDM() + "\n" +
           "DF: " + getDF() + "\n";
    }
}
