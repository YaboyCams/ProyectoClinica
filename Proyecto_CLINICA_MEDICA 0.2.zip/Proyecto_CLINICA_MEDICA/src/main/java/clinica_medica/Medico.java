/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clinica_medica;

import java.io.Serializable;

/**
 *
 * @author callo
 */
public class Medico extends HorariosTrabajo implements Serializable {
    private String nombre;
    private int identificacion;
    private String apellidos;
    private String correo;
    private int telefono;
    private String fecha;
    private String direccion;
    private String especialidad;
    private int costo;
    private String duracion;   
    
    
    public Medico(){}
    public Medico(String pLM, String pLF, String pKM, String pKF, String pMM, String pMF, String pJM, String pJF, String pVM, String pVF, String pSM, String pSF, String pDM, String pDF,int pIdentificacion, String pNombre, String pApellidos, String pCorreo, int pTelefono, String pFecha, String pDireccion, String pEspecialidad, int pCosto, String pDuracion){
        
        super(pLM,pLF,pKM,pKF,pMM,pMF,pJM,pJF,pVM,pVF,pSM,pSF,pDM,pDF);
        
        setNombre(pNombre);
        setIdentificacion(pIdentificacion);
        setApellidos(pApellidos);
        setCorreo(pCorreo);
        setTelefono(pTelefono);
        setFecha(pFecha);
        setDireccion(pDireccion);
        setEspecialidad(pEspecialidad);
        setCosto(pCosto);
        setDuracion(pDuracion);
        
        
    }
    public void setDuracion(String pDuracion){
        duracion = pDuracion;
    }
    public String getDuracion(){
        return duracion;
    }
    public void setNombre(String pNombre){
        nombre = pNombre;
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public void setIdentificacion(int pIdentificacion){
        identificacion = pIdentificacion;
    }
    
    public int getIdentificacion(){
        return identificacion;
    }
    
    public void setApellidos(String pApellidos){
        apellidos = pApellidos;
    }
    
    public String getApellidos(){
        return apellidos;
    }
    
    public void setCorreo(String pCorreo){
        correo = pCorreo;
    }
    
    public String getCorreo(){
        return correo;
    }
    
    public void setTelefono(int pTelefono){
        telefono = pTelefono;
    }
    
    public int getTelefono(){
        return telefono;
    }
    public void setFecha(String pFecha){
        fecha = pFecha;
    }
    public String getFecha(){
        return fecha;
    }
    public void setDireccion(String pDireccion){
        direccion = pDireccion;
    }
    public String getDireccion(){
        return direccion;
    }
    public void setEspecialidad(String pEspecialidad){
        especialidad = pEspecialidad;
    }
    public String getEspecialidad(){
        return especialidad;
    }
    public void setCosto(int pCosto){
        costo = pCosto;
    }
    public int getCosto(){
        return costo;
    }
    public String toString(){
        return "Nombre: " + getNombre() + "\n" +
           "Apellidos: " + getApellidos() + "\n" +
           "Identificacion: " + getIdentificacion() + "\n" +
           "Correo: " + getCorreo() + "\n" +
           "Telefono: " + getTelefono() + "\n" +
           "Direccion: " + getDireccion() + "\n" +
           "Fecha: " + getFecha() + "\n" +
           "Especialidad: " + getEspecialidad() + "\n" +
           "Costo: " + getCosto() + "\n" +
           "Duracion: " + getDuracion() + "\n" +
           "Horarios de trabajo: " + super.toString();
    }
}

