/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clinica_medica;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author callo
 */
public class Lista_Medicos implements Serializable {
    private List<Medico> lista_Medicos;
    
    public Lista_Medicos(){
        lista_Medicos = new ArrayList<>();
    }
    public boolean agregarAListaMedicos(Medico medico){
        //Sacar identificacion
        int identificacion = medico.getIdentificacion();
        //Si es -1 con la identificacion mandada se puede agregar
        if (estaVacia() == true){
            lista_Medicos.add(medico);
            return true;
        }
        else if(buscarMedicos(identificacion) == -1){
            //añade el estudiante
            lista_Medicos.add(medico);
            return true;
        }
        
        return false;
    }
    public int buscarMedicos(int identificacion){
        // inicializacion i //mienstar i sea menor al tamaño de la lista// i aumenta en uno
        if (estaVacia() == true){
            return -1;
        }        
        for (int i = 0; i < lista_Medicos.size(); i++) {
            Medico comprobar = lista_Medicos.get(i);
            if (comprobar.getIdentificacion() == identificacion){
                //si esta en la lista
                return i;
            }

        }
        return -1;
    }
    public boolean eliminarDelista_Medicos(Paciente paciente) {
        // Sacar el resultado de llamado de funcion
        int ident = paciente.getIdentificacion();
        //ind de indice para utilizar más tarde
        int ind = buscarMedicos(ident);
        if (ind != -1) {
            lista_Medicos.remove(ind);
            return true;
        }
        return false;
    }
    public void desplegarlista_Medicos() {
        // inicializacion en elemento estudiante in lista de estudiante
        for (Medico medico : lista_Medicos) {
            System.out.println(medico.toString());
        }
    }
    public boolean estaVacia() {
        return lista_Medicos.isEmpty();
    }

    public static Lista_Medicos leerListaMedicos(){
        //fichero de lectura
        FileInputStream fichero = null;
        Lista_Medicos contenido = null;
        
        try{
            
            fichero = new FileInputStream("ListaMedicos.dat");
            //objeto de lectura
            ObjectInputStream sacarMaterial = new ObjectInputStream(fichero);
            contenido = (Lista_Medicos) sacarMaterial.readObject();
            
        }
        catch(FileNotFoundException ex){
            ex.printStackTrace();
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
        catch(ClassNotFoundException ex){
            ex.printStackTrace();
        }          
        return contenido;
    }
    public Medico getMedico(int identificacion){
        for (int i = 0; i < lista_Medicos.size(); i++) {
            Medico comprobar = lista_Medicos.get(i);
            if (comprobar.getIdentificacion() == identificacion){
                //si esta en la lista
                return comprobar;
            }
        }
        return null;
    }
}    

