
package clinica_medica;


import static clinica_medica.Lista_Medicos.leerListaMedicos;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import static clinica_medica.Proyecto_CLINICA_MEDICA.grabarDiccionarioHorarios;
import static clinica_medica.Proyecto_CLINICA_MEDICA.leerFechaSeleccionada;
import java.time.Instant;
import java.util.Date;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;


public class Horarios extends javax.swing.JFrame {

    public Horarios() {
        initComponents();
        Lista_Medicos lista = leerListaMedicos();
        Date fecha = leerFechaSeleccionada();
        System.out.println(fecha);
        
        //Pasar de date a localdatetime
        Instant instant = fecha.toInstant();
        LocalDateTime fechaLocal = instant.atZone(ZoneId.systemDefault()).toLocalDateTime();
        DayOfWeek diaSemana = fechaLocal.getDayOfWeek();
        int valor = diaSemana.getValue();
        String dia;
        switch (valor){
            case 1 ->
                dia = "Lunes";
            case 2 ->
                dia = "Martes";
            case 3 ->
                dia = "Miercoles";
            case 4 ->
                dia = "Jueves";
            case 5 ->
                dia = "Viernes";
            case 6 ->
                dia = "Sabado";
            case 7 ->
                dia = "Domingo";
            default ->
                dia = "";
                
        }
        DiccionarioHorarios dict = new DiccionarioHorarios();
        dict.agregarAlDicionarioInterno(lista);
        
        List<Integer> ids = obtenerIds(dia, dict);
        List<String> nombres = obtenerNombres(ids, lista);
        dict.imprimirDiccionario();
        grabarDiccionarioHorarios(dict);
        System.out.println(nombres);

        if (nombres.isEmpty()){
            MedicosCombobox.addItem("No hay");
            JOptionPane.showMessageDialog(this, "Todavía no hay médicos registrados.");
            this.dispose();
        } else {
            for(String nombre : nombres){
                MedicosCombobox.addItem(nombre);
        }}
        
        MedicosCombobox.setSelectedIndex(-1);
        
    }
    
    private List<Integer> obtenerIds(String dia, DiccionarioHorarios dict){
        
        List<Integer> ids = new ArrayList<>();
        Map<Integer, List<LocalTime>> dictEncontrado = null;
        for(Map.Entry<String, Map<Integer, List<LocalTime>>> entry : dict.setEntry()){
            if(entry.getKey() == dia){
                dictEncontrado = entry.getValue();
                break;
            }
        }
         if (dictEncontrado != null){
             for(Map.Entry<Integer, List<LocalTime>> entry : dictEncontrado.entrySet()){
                 int id = entry.getKey();
                 ids.add(id);
             }
         }
        
        /*f (lista.estaVacia() == false){
            for (int i = 0; i < lista.largo(); i++){
                Medico medico = lista.acceso(i);
                String nombre = medico.getNombre();
                nombres.add(nombre);}
        }*/

        return ids;
    }
    
    private List<LocalTime> obtenerTiempos(String dia, DiccionarioHorarios dict,int id){
        
        List<LocalTime> tiempos = new ArrayList<>();
        Map<Integer, List<LocalTime>> dictEncontrado = null;
        for(Map.Entry<String, Map<Integer, List<LocalTime>>> entry : dict.setEntry()){
            if(entry.getKey() == dia){
                dictEncontrado = entry.getValue();
                break;
            }
        }
         if (dictEncontrado != null){
             for(Map.Entry<Integer, List<LocalTime>> entry : dictEncontrado.entrySet()){
                 if(id == entry.getKey()){
                     tiempos = entry.getValue();
                     break;
                 }
             }
         }
         return tiempos;
    }
    
    private List<String> obtenerNombres(List<Integer> listaIds, Lista_Medicos listaMedicos){
        List<String> nombres = new ArrayList<>();
        for (int id : listaIds){
            if(listaMedicos.estaVacia() == false){
                for (int i = 0; i < listaMedicos.largo(); i++){
                    Medico medico = listaMedicos.acceso(i);
                    if (medico.getIdentificacion() == id){
                        String nombre = medico.getNombre();
                        String apellidos = medico.getApellidos();
                        String completo = nombre + " " + apellidos;
                        nombres.add(completo);
                    } 
                } 
            }
        }
        return nombres;
    }
    
    private void MostrarHorarios(String completo){
        
        // variables
        Lista_Medicos lista = leerListaMedicos();
        Date fecha = leerFechaSeleccionada();
        System.out.println(fecha);
        
        //Pasar de date a localdatetime
        Instant instant = fecha.toInstant();
        LocalDateTime fechaLocal = instant.atZone(ZoneId.systemDefault()).toLocalDateTime();
        DayOfWeek diaSemana = fechaLocal.getDayOfWeek();
        int valor = diaSemana.getValue();
        String dia;
        switch (valor){
            case 1 ->
                dia = "Lunes";
            case 2 ->
                dia = "Martes";
            case 3 ->
                dia = "Miercoles";
            case 4 ->
                dia = "Jueves";
            case 5 ->
                dia = "Viernes";
            case 6 ->
                dia = "Sabado";
            case 7 ->
                dia = "Domingo";
            default ->
                dia = "";
                
        }
        DiccionarioHorarios dict = new DiccionarioHorarios();
        dict.agregarAlDicionarioInterno(lista);
        LocalTime horaInicio = LocalTime.now();
        LocalTime horaFinal = LocalTime.now();
        List<Integer> ids = obtenerIds(dia, dict);
        for (int id : ids){
            System.out.println("hola");
            Medico medico = lista.getMedico(id);
            String nombre = medico.getNombre();
            String apellidos = medico.getApellidos();
            String comp = nombre + " " + apellidos;
            if (comp.equals(completo)){
                System.out.println("z");
                String duracion = medico.getDuracion();
                int i = 0;
                switch (duracion) {
                    case "10 minutos":
                        i = 10;
                        break;
                    case "15 minutos":
                        i = 15;
                        break;
                    case "20 minutos":
                        i = 20;
                        break;
                    case "25 minutos":
                        i = 25;
                        break;
                    case "30 minutos":
                        i = 30;
                        break;
                    case "35 minutos":
                        i = 35;
                        break;
                    case "40 minutos":
                        i = 40;
                        break;
                    case "45 minutos":
                        i = 45;
                        break;
                    case "50 minutos":
                        i = 50;
                        break;
                    case "55 minutos":
                        i = 55;
                        break;
                    case "1 hora":
                        i = 60;
                        break;
                    case "2 horas":
                        i = 120;
                        break;
                }
                Duration minutos = Duration.ofMinutes(i);
                List<LocalTime> tiempos = obtenerTiempos(dia, dict, id);
                horaInicio = tiempos.get(0);
                horaFinal = tiempos.get(1);
                while (!horaInicio.isAfter(horaFinal)) {
                    System.out.println("A");
                    DateTimeFormatter formateador = DateTimeFormatter.ofPattern("HH:mm");
                    String horaFormateada = horaInicio.format(formateador);
                    HorarioCombobox.addItem(horaFormateada);
                    horaInicio = horaInicio.plus(minutos);
                }
                break;
            }
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        BotonRegresar = new javax.swing.JButton();
        MedicosCombobox = new javax.swing.JComboBox<>();
        HorarioCombobox = new javax.swing.JComboBox<>();
        BotonMostrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        BotonRegresar.setText("Regresar");
        BotonRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonRegresarActionPerformed(evt);
            }
        });

        MedicosCombobox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MedicosComboboxActionPerformed(evt);
            }
        });

        HorarioCombobox.setEnabled(false);

        BotonMostrar.setText("Mostrar");
        BotonMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonMostrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(BotonRegresar)
                .addGap(24, 24, 24))
            .addGroup(layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(MedicosCombobox, 0, 176, Short.MAX_VALUE)
                    .addComponent(HorarioCombobox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(BotonMostrar)
                .addContainerGap(55, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(89, 89, 89)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(MedicosCombobox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BotonMostrar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                .addComponent(HorarioCombobox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(BotonRegresar)
                .addGap(39, 39, 39))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MedicosComboboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedicosComboboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MedicosComboboxActionPerformed

    private void BotonRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonRegresarActionPerformed
        Calendario C = new Calendario();
        C.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BotonRegresarActionPerformed

    private void BotonMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonMostrarActionPerformed
        String nombre = (String) MedicosCombobox.getSelectedItem();
        if (HorarioCombobox.getItemCount() > 0){
            HorarioCombobox.removeAllItems();
        }
        MostrarHorarios(nombre);
        HorarioCombobox.setEnabled(true);
    }//GEN-LAST:event_BotonMostrarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Horarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Horarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Horarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Horarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Horarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonMostrar;
    private javax.swing.JButton BotonRegresar;
    private javax.swing.JComboBox<String> HorarioCombobox;
    private javax.swing.JComboBox<String> MedicosCombobox;
    private javax.swing.ButtonGroup buttonGroup1;
    // End of variables declaration//GEN-END:variables
}
