/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clinica_medica;

import java.io.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author callo
 */
public class Lista_Pacientes implements Serializable {
    private List<Paciente> lista_Pacientes;
    
    public Lista_Pacientes(){
        lista_Pacientes = new ArrayList<>();
    }
    public boolean agregarAListaPacientes(Paciente paciente){
        //Sacar identificacion
        int identificacion = paciente.getIdentificacion();
        //Si es -1 con la identificacion mandada se puede agregar
        if (estaVacia() == true){
            lista_Pacientes.add(paciente);
            return true;
        }
        else if(buscarPacientes(identificacion) == -1){
            //añade el estudiante
            lista_Pacientes.add(paciente);
            return true;
        }
        
        return false;
    }
    public int buscarPacientes(int identificacion){
        // inicializacion i //mienstar i sea menor al tamaño de la lista// i aumenta en uno
        if (estaVacia() == true){
            return -1;
        }        
        for (int i = 0; i < lista_Pacientes.size(); i++) {
            Paciente comprobar = lista_Pacientes.get(i);
            if (comprobar.getIdentificacion() == identificacion){
                //si esta en la lista
                return i;
            }

        }
        return -1;
    }
    public boolean eliminarDeListaPacientes(Paciente paciente) {
        // Sacar el resultado de llamado de funcion
        int ident = paciente.getIdentificacion();
        //ind de indice para utilizar más tarde
        int ind = buscarPacientes(ident);
        if (ind != -1) {
            lista_Pacientes.remove(ind);
            return true;
        }
        return false;
    }
    public void desplegarListaPacientes() {
        // inicializacion en elemento estudiante in lista de estudiante
        for (Paciente paciente : lista_Pacientes) {
            System.out.println(paciente.toString());
        }
    }
    public boolean estaVacia() {
        return lista_Pacientes.isEmpty();
    }
    public static Lista_Pacientes leerListaPacientes(){
        //fichero de lectura
        FileInputStream fichero = null;
        Lista_Pacientes contenido = null;
        
        try{
            
            fichero = new FileInputStream("ListaPacientes.dat");
            //objeto de lectura
            ObjectInputStream sacarMaterial = new ObjectInputStream(fichero);
            contenido = (Lista_Pacientes) sacarMaterial.readObject();
            
        }
        catch(FileNotFoundException ex){
            ex.printStackTrace();
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
        catch(ClassNotFoundException ex){
            ex.printStackTrace();
        }          
        return contenido;
    }
    public Paciente getPaciente(int identificacion){
        for (int i = 0; i < lista_Pacientes.size(); i++) {
            Paciente comprobar = lista_Pacientes.get(i);
            if (comprobar.getIdentificacion() == identificacion){
                //si esta en la lista
                return comprobar;
            }
        }
        return null;
    }
}

