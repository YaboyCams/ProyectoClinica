/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package clinica_medica;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;

/**
 *
 * @author callo
 */
public class Proyecto_CLINICA_MEDICA{

    public static boolean esCorreo(String correo){
        Pattern patroncito = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        Matcher comparar=patroncito.matcher(correo);
        return comparar.find();
     }
    public static boolean esFechaValida(String fecha) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
        sdf.setLenient(false); // Hace que SimpleDateFormat sea estricto en cuanto a la validación.

        try {
            Date date = sdf.parse(fecha);
            // Si no lanza excepción, la fecha es válida.
            return true;
        } catch (ParseException e) {
            // La fecha no es válida.
            return false;
        }
    }
    public static void grabarListaPacientes(Lista_Pacientes pacientes){
        // Objeto para sacar archivo
        FileOutputStream fichero = null;
        try{
            //Se abre paso a un archivo
            fichero = new FileOutputStream("ListaPacientes.dat");
            //objeto de escritura
            ObjectOutputStream insertar = new ObjectOutputStream(fichero);
            //se escribe
            insertar.writeObject(pacientes);
            System.out.println("Grabado exitoso"); 
            fichero.close();
        }
        catch(FileNotFoundException ex){
            ex.printStackTrace();
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
        
        finally{
            try{
                fichero.close();
            }
            catch(IOException ex){
                ex.printStackTrace();
            }
        }        
    }
    public static void grabarListaMedicos(Lista_Medicos medico){
        // Objeto para sacar archivo
        FileOutputStream fichero = null;
        try{
            //Se abre paso a un archivo
            fichero = new FileOutputStream("ListaMedicos.dat");
            //objeto de escritura
            ObjectOutputStream insertar = new ObjectOutputStream(fichero);
            //se escribe
            insertar.writeObject(medico);
            System.out.println("Grabado exitoso"); 
            fichero.close();
        }
        catch(FileNotFoundException ex){
            ex.printStackTrace();
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
        
        finally{
            try{
                fichero.close();
            }
            catch(IOException ex){
                ex.printStackTrace();
            }
        }        
    }
    public static boolean esHoraValida(String hora) {
        String formatoHora = "^([01]?[0-9]|2[0-3]):[0-5][0-9]$";
        return hora.matches(formatoHora);
    }
    public static boolean validarHora(String hora1, String hora2, String duracion){
        
        if((esHoraValida(hora1)== true)&&(esHoraValida(hora2)== true)){
            int ind_1 = hora1.indexOf(":");
            int ind_2 = hora2.indexOf(":");
            
            String valor1 = hora1.substring(0, ind_1);
            String valor2 = hora1.substring(ind_1 + 1);
            String valor3 = hora2.substring(0, ind_2);
            String valor4 = hora2.substring(ind_2 + 1);
            try {
                // Intentar convertir la cadena en un número entero
                int v1 = Integer.parseInt(valor1);
                int v2 = Integer.parseInt(valor2);
                int v3 = Integer.parseInt(valor3);
                int v4 = Integer.parseInt(valor4);
                
                
                System.out.println(calcularDiferenciaDeHoras(v1,v2,v3,v4));
                
                int diferencia = calcularDiferenciaDeHoras(v1,v2,v3,v4);
                switch(duracion){
                    case "10 minutos":
                        if(diferencia >= 10){
                            return true;
                        }
                        return false;
                    case "15 minutos":
                        if(diferencia >= 15){
                            return true;
                        }
                        return false;
                    case "20 minutos":
                        if(diferencia >= 20){
                            return true;
                        }
                        return false;
                    case "25 minutos":
                        if(diferencia >= 25){
                            return true;
                        }
                        return false;
                    case "30 minutos":
                        if(diferencia >= 30){
                            return true;
                        }
                        return false;
                    case "35 minutos":
                        if(diferencia >= 35){
                            return true;
                        }
                        return false;
                    case "40 minutos":
                        if(diferencia >= 40){
                            return true;
                        }
                        return false;
                    case "45 minutos":
                        if(diferencia >= 45){
                            return true;
                        }
                        return false;
                    case "50 minutos":
                        if(diferencia >= 50){
                            return true;
                        }
                        return false;
                    case "55 minutos":
                        if(diferencia >= 55){
                            return true;
                        }
                        return false;
                    case "1 hora":
                        if(diferencia >= 60){
                            return true;
                        }
                        return false;
                    case "2 horas":
                        if(diferencia >= 120){
                            return true;
                        }
                        return false;
                    
                }

            } 
            catch (NumberFormatException e) {
                System.out.println("No se pudo convertir el valor a número entero.");
            }
        }
        return false;
    }
    public static int calcularDiferenciaDeHoras(int hora1, int minutos1, int hora2, int minutos2) {
            //Multiplicamos por 60 
            int hora1EnMinutos = hora1 * 60 + minutos1;
            int hora2EnMinutos = hora2 * 60 + minutos2;

            // Calcular la diferencia en minutos
            int diferenciaEnMinutos = hora2EnMinutos - hora1EnMinutos;
            
            return diferenciaEnMinutos;
        }

    public static void main(String[] args) {
        
        //Crear objeto de ventana
        //Ventana v1 = new Ventana();
        Menu menu = new Menu();
        menu.setVisible(true);
        //v1.setVisible(true);
        
        Lista_Pacientes lista = new Lista_Pacientes();
        Lista_Medicos listaM = new Lista_Medicos();
        
        boolean messi = lista.estaVacia();
        System.out.println(messi);
        //grabarListaPacientes(lista);
        grabarListaMedicos(listaM);
        
        System.out.println(validarHora("8:00", "8:01","10 minutos"));
        System.out.println(esHoraValida("25:00"));
        System.out.println(esHoraValida(""));
    }

}
