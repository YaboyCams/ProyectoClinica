
package clinica_medica;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.io.Serializable;

public class DiccionarioCitas implements Serializable{
    private Map<Integer, Map<Date, List<String>>> fechas;

    public DiccionarioCitas(){
        fechas = new LinkedHashMap<>();
    }
    
    public void AgregarIdentiificaiones(Lista_Medicos listaM){
        Map<Date, List<String>> Citas = new LinkedHashMap<>();
        for (int i = 0; i < listaM.largo(); i++){
            Medico medico = listaM.acceso(i);
            int id = medico.getIdentificacion();
            fechas.put(id, Citas);
        }
    }
    
    public void AgregarCitas(Date dia, String hora,int id){
        Map<Date, List<String>> citas = fechas.get(id);
        if (citas != null){
            List<String> horas = citas.get(dia);
            if (horas == null){
                horas = new ArrayList<>();
                citas.put(dia, horas);
            }
           horas.add(hora);
        }
        
    }
    
    public boolean EncontrarHora(Date dia, String hora, int id) {
        Map<Date, List<String>> citas = fechas.get(id);
        if (citas != null) {
            List<String> horas = citas.get(dia);
            if (horas != null) {
                for (int i = 0; i < horas.size(); i++) {
                    if (horas.get(i).equals(hora)) {
                        return true;
                    }
                }
            }

        }
        return false;
    }
}
