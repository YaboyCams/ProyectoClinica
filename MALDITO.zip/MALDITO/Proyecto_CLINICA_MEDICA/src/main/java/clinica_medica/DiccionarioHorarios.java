
package clinica_medica;


import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;


public class DiccionarioHorarios implements Serializable {
    private Map<String, Map<Integer, List<LocalTime>>> dias;

    public DiccionarioHorarios(){
        dias = new LinkedHashMap<>();
        String[] diasSemana  = {"Domingo","Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado"};
        for (String dia : diasSemana){
            Map<Integer, List<LocalTime>> horasMedicos = new LinkedHashMap<>();
            dias.put(dia, horasMedicos);
        }
    }
    
    public Map<Integer, List<LocalTime>> acceso(String dia){
        return dias.get(dia);
    }
    
    public void agregarAlDicionarioInterno(Lista_Medicos medicos){
        for (int i = 0; i < medicos.largo(); i++){
            Medico medico = medicos.acceso(i);
            int identificacion = medico.getIdentificacion();
            String LI = medico.getLM();
            String LF = medico.getLF();
            String KI = medico.getKM();
            String KF = medico.getKF();
            String MI = medico.getMM();
            String MF = medico.getMF();
            String JI = medico.getJM();
            String JF = medico.getJF();
            String VI = medico.getVM();
            String VF = medico.getVF();
            String SI = medico.getSM();
            String SF = medico.getSF();
            String DI = medico.getDM();
            String DF = medico.getDF();
            
            
            int cont = 1;
            String[] horas = {LI,LF,KI,KF,MI,MF,JI,JF,VI,VF,SI,SF,DI,DF};
            LocalTime h = null;
            for (String hora : horas){
                if (!"N".equals(hora)){
                    DateTimeFormatter formato = DateTimeFormatter.ofPattern("H:mm");
                    try{
                        h = LocalTime.parse(hora, formato);
                    }catch(Exception e) {
                        e.printStackTrace();
                    }
                    String dia;
                    switch(cont){
                        case 1,2 ->dia = "Lunes";
                        case 3,4 ->dia = "Martes";
                        case 5,6 ->dia = "Miercoles";
                        case 7,8 ->dia = "Jueves";
                        case 9,10 ->dia = "Viernes";
                        case 11,12 ->dia = "Sabado";
                        case 13,14 ->dia = "Domingo";
                        default -> dia = "";
                        
                    }
                    if (!dia.isEmpty()){
                        Map<Integer, List<LocalTime>> horasMedicos = dias.get(dia);
                        
                        if (horasMedicos == null){
                            horasMedicos = new HashMap<>();
                            dias.put(dia, horasMedicos);
                        }
                        List<LocalTime> horarios = horasMedicos.get(identificacion);
                        if (horarios == null){
                            horarios = new ArrayList<>();
                            horasMedicos.put(identificacion, horarios);
                        }
               
                        if(cont % 2 != 0){
                            horarios.add(0, h);
                        } else{
                            horarios.add(1, h);
                        }
                    }
                        
                }
            cont++;   
            }
            
        }
    }
        

    

    
    public void imprimirDiccionario(){
        for (Map.Entry<String, Map<Integer, List<LocalTime>>> entry : dias.entrySet())
        {
            String dia = entry.getKey();
            Map<Integer, List<LocalTime>>horasMedicos = entry.getValue();
            System.out.println("Dia : " + dia);
            
            for(Map.Entry<Integer, List<LocalTime>> innerEntry : horasMedicos.entrySet()){
                Integer identificacion = innerEntry.getKey();
                List<LocalTime> horarios = innerEntry.getValue();
                System.out.println(" Identificación: " + identificacion);
                System.out.print("  Horarios: ");
                for (LocalTime hora: horarios){
                    System.out.print(hora + ", ");
                }
                System.out.println("\n");
                
            }
        }
    }
    
    public Set<Map.Entry<String, Map<Integer, List<LocalTime>>>> setEntry(){
        return dias.entrySet();
    }
    
}
