/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clinica_medica;

import java.io.Serializable;

/**
 *
 * @author callo
 */
public class Paciente implements Serializable, Comparable<Paciente>{
    private String nombre;
    private int identificacion;
    private String apellidos;
    private String correo;
    private int telefono;
    private String fecha;
    private String direccion;
    
    public Paciente(){}
    public Paciente(int pIdentificacion, String pNombre, String pApellidos, String pCorreo, int pTelefono, String pFecha, String pDireccion){
        setNombre(pNombre);
        setIdentificacion(pIdentificacion);
        setApellidos(pApellidos);
        setCorreo(pCorreo);
        setTelefono(pTelefono);
        setFecha(pFecha);
        setDireccion(pDireccion);
        
    }
    public void setNombre(String pNombre){
        nombre = pNombre;
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public void setIdentificacion(int pIdentificacion){
        identificacion = pIdentificacion;
    }
    
    public int getIdentificacion(){
        return identificacion;
    }
    
    public void setApellidos(String pApellidos){
        apellidos = pApellidos;
    }
    
    public String getApellidos(){
        return apellidos;
    }
    
    public void setCorreo(String pCorreo){
        correo = pCorreo;
    }
    
    public String getCorreo(){
        return correo;
    }
    
    public void setTelefono(int pTelefono){
        telefono = pTelefono;
    }
    
    public int getTelefono(){
        return telefono;
    }
    public void setFecha(String pFecha){
        fecha = pFecha;
    }
    public String getFecha(){
        return fecha;
    }
    public void setDireccion(String pDireccion){
        direccion = pDireccion;
    }
    public String getDireccion(){
        return direccion;
    }
    public String toString(){
        return "Nombre: " + getNombre() + "\n" +
                "Apellidos: " + getApellidos() + "\n" + 
                "Identificacion: " + getIdentificacion() + "\n" +
                "Correo: " + getCorreo() + "\n" +
                "Telefono: " + getTelefono() + "\n" +
                "Direccion: " + getDireccion() + "\n" +
                "Fecha: " + getFecha() + "\n";
    }
    @Override
    public int compareTo(Paciente e) {
        
        // Comparar por apellidos
        int comparacion = apellidos.compareTo(e.apellidos);

        // Si los apellidos son iguales, compara por nombre
        if (comparacion == 0) {
            comparacion = nombre.compareTo(e.nombre);
        }

        return comparacion;
    }
}
