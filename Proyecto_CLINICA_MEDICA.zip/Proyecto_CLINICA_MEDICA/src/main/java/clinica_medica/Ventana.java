package clinica_medica;


import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class Ventana extends JFrame {
    public Ventana(){
        //Tamaño
        setSize(500,500);
        //Para que cuando se le de a la x cierre el programa
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        //Ponerle Titulo
        setTitle("Clinica Medica");
        /*
        
        setLocation(100,200);
        
        CREACION DE LA VENTANA (Eje x, Eje y, Ancho, alto)
        setBounds(100,200,500,500);
        */
        //Poner en el centro
        setLocationRelativeTo(null);
        ponerWidgets();
    }    
    private void ponerWidgets(){
        JPanel panel = new JPanel();//Para poner cosas dentro de la ventana 
        //panel.setBackground(Color.PINK); //Poner color
        panel.setLayout(null);//Desactivar diseño por defecto
        this.getContentPane().add(panel);//Agregar panel a la ventana
        
        JLabel MenuEtiqueta = new JLabel("CLINICA MÉDICA MENÚ",SwingConstants.CENTER); // Label
        MenuEtiqueta.setOpaque(true);//PARA PINTAR ETIQUETA
        //MenuEtiqueta.setText("CLINICA MÉDICA MENÚ");
        MenuEtiqueta.setBounds(175,0,150,50);
        //MenuEtiqueta.setForeground(Color.WHITE); //color de letra
        MenuEtiqueta.setBackground(Color.pink);
        panel.add(MenuEtiqueta); //Poner etiqueta
        //setFont(new Font("arial",Font.PLAIN,50));
        //setHorizontalAlignment(SwingConstants.CENTER);
    }   
    
}
