/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package clinica_medica;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author callo
 */
public class Proyecto_CLINICA_MEDICA{

    public static boolean esCorreo(String correo){
        Pattern patroncito = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        Matcher comparar=patroncito.matcher(correo);
        return comparar.find();
     }
    public static boolean esFechaValida(String fecha) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
        sdf.setLenient(false); // Hace que SimpleDateFormat sea estricto en cuanto a la validación.

        try {
            Date date = sdf.parse(fecha);
            // Si no lanza excepción, la fecha es válida.
            return true;
        } catch (ParseException e) {
            // La fecha no es válida.
            return false;
        }
    }
    public static void grabarListaPacientes(Lista_Pacientes pacientes){
        // Objeto para sacar archivo
        FileOutputStream fichero = null;
        try{
            //Se abre paso a un archivo
            fichero = new FileOutputStream("ListaPacientes.dat");
            //objeto de escritura
            ObjectOutputStream insertar = new ObjectOutputStream(fichero);
            //se escribe
            insertar.writeObject(pacientes);
            System.out.println("Grabado exitoso"); 
            fichero.close();
        }
        catch(FileNotFoundException ex){
            ex.printStackTrace();
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
        
        finally{
            try{
                fichero.close();
            }
            catch(IOException ex){
                ex.printStackTrace();
            }
        }        
    }    
    public static void main(String[] args) {
        
        //Crear objeto de ventana
        //Ventana v1 = new Ventana();
        Menu menu = new Menu();
        menu.setVisible(true);
        //v1.setVisible(true);
        Lista_Pacientes lista = new Lista_Pacientes();
        boolean messi = lista.estaVacia();
        System.out.println(messi);
        grabarListaPacientes(lista);   
    }
}
